$(document).ready(function() {
    $("p").hide();
    $("#q1").mouseover(function() {$("#hidden1").toggle();});
     $("#q1").mouseout(function(){$("#hidden1").toggle(); })
    $("#q2").mouseover(function() {$("#hidden2").show();});
    $("#q2").mouseout(function(){$("#hidden2").toggle(); })
    $("#q3").mouseover(function() {$("#hidden3").show();});
     $("#q3").mouseout(function(){$("#hidden3").toggle(); })
}); // end ready