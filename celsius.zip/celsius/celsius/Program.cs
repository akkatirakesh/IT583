﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace celsius
{
    class Program
    {
        static void Main(string[] args)
        {
            double C;
            Console.Write("Enter Fahrenheit temperature : ");
            double F = Convert.ToDouble(Console.ReadLine());
            C = (F - 32) * 5 / 9;
            Console.WriteLine("The Celsius temperature is " + C);
            Console.ReadLine();
        }
    }
}
