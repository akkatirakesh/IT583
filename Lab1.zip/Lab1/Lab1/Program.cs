﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            char s, f;
            bool spicy, fancy;
                Console.WriteLine("Do you like spicy food?(y/n):");
            s= Convert.ToChar(Console.ReadLine());

            if (s == 'y' || s == 'Y')
                spicy = true;

            else
                spicy = false;
            Console.WriteLine("Do you want to go to a fancy restaurant?(y/n):");
            f= Convert.ToChar(Console.ReadLine());
            if (f == 'y' || f == 'Y')
                fancy = true;

            else
                fancy = false;
            if (spicy && fancy)
                Console.WriteLine("I suggest you go to Thai Garden Palace.");
            if(!spicy && !fancy)
                Console.WriteLine("I suggest you go to Joe's Dinner.");
            if(spicy && !fancy)
                Console.WriteLine("I suggest you go to Alberto's Tacqueria.");
            if(!spicy && fancy)
                Console.WriteLine("I suggest you go to Chez Paris");
            Console.ReadLine();



        }
    }
}
